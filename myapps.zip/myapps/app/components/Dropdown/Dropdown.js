
import React from "react";

import "./Dropdown.css";

const Dropdown = ({ placeHolder,options }) => {
    const getDisplay = () => {
        return placeHolder;
    };

    return (
        <div className="dropdown-container">
            <div className="dropdown-input">
                <div className="dropdown-menu">
                    {options.map((option) => (
                        <div key={option.value}  className="dropdown-item">
                            {option.label} 
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Dropdown;