import styled from "@emotion/styled";

const StyledButton = ({
  className,
  children,
  dataTestId,
  disabled,
  onClick,
  style,
  type
}) => (
  <button
    data-testid={dataTestId}
    disabled={disabled}
    type={type}
    className={className}
    onClick={onClick}
    style={style}
  >
    {children}
  </button>
);

const Button = styled(StyledButton)`
  background-color: #0000FF;
  border-radius: 10px;
  width: ${({ width }) => width || "30%"};
  padding: ${({ padding }) => padding || "10px"};
  font-size: ${({ fontSize }) => fontSize || "12px"};
  margin: ${({ margin }) => margin || "auto"};
  max-width: ${({ maxWidth }) => maxWidth || "auto"};
  letter-spacing: 1px;

  :hover {
    background-color: #FFA500;
    color: #fff;
  }

  :focus {
    outline: 0;
  }
`;

export default Button;
