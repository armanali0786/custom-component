'use client';
import React, { useState } from "react";
import Button from "../Button/Button";
import Container from "../Container/Container";
import Input from "../Input/Input";
import Form from "../Form/Form";
import Checkbox from "../Checkbox/Checkbox";
import Dropdown from "../Dropdown/Dropdown";

const FormInput = () => {
  const options = [
    { value: "node", label: "Node" },
    { value: "react", label: "React" },
  ];

  const handleSelect = (selectedOption) => {
    console.log("Selected option:", selectedOption);
  };

  const [state, setState] = useState({
    name: "",
    email: "",
    password: "",
    errors: false,
  });
  const { name, email, errors, password } = state;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = !name || !email || !password;
    setState((prevState) => ({
      ...prevState,
      errors,
    }));
    if (!errors) alert(JSON.stringify({ name, email, password }, null, 4));
  };

  return (
    <Container>
      <Form background="#808080" borderRadius="15px" onSubmit={handleSubmit}>
        <h1>Register Page</h1>
        <Input
          required
          type="text"
          name="name"
          placeholder="Enter your Name..."
          value={name}
          errors={errors}
          onChange={handleChange}
        />
        <Input
          required
          type="email"
          name="email"
          placeholder="Enter your email..."
          value={email}
          errors={errors}
          onChange={handleChange}
        />
        <Input
          required
          type="password"
          name="password"
          placeholder="Enter your password..."
          value={password}
          errors={errors}
          onChange={handleChange}
        />
        <Checkbox label="Male" name="male" checked={true} onChange={handleChange} />
        <Checkbox label="Female" name="female" checked={true} onChange={handleChange} disabled />
        <Checkbox label="Others" name="others" onChange={handleChange} />
        {/* <Dropdown placeHolder="Select..." options={options} onSelect={handleSelect} /> */}
        <Button type="submit" margin="10px 0 20px 0">
          Log in
        </Button>
      </Form>
    </Container>
  );
};

export default FormInput;
