import React from 'react'
import Form from './components/FormInput/FormInput'
export default function Home() {
  return (
    <>
    <div>
    <Form/>
    </div>
    </>
  )
}
